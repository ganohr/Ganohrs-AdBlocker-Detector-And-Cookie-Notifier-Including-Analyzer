=== Avoid the chromium lazy loading broken characters bug ===
Contributors: Ganohr
Tags: CSS,Lazy Loading,JavaScript,Chromium,bugfix
Donate link: http://amzn.asia/gw9HHbg
Requires at least: 5.0
Tested up to: 6.1.1
Requires PHP: 5.0
Stable tag: trunk
License: GPLv2
License URI: http://www.opensource.jp/gpl/gpl.ja.html

Avoid the chromium lazy loading broken characters bug.

== Description ==
Avoid the chromium lazy loading broken characters bug.

== Frequently Asked Questions == 
Q. What's this?
A. Have you ever seen a site with Google Chrome or the latest Microsoft Edge and found the latter half of the characters broken? This plugin will force fix it.

== Screenshots ==
1. Chromium text lazy loading has a bug for latter half of characters broken.
2. It's can for fix it.


== Changelog ==
0.0.1 New Release


== Upgrade Notice ==
0.0.1 New Release
