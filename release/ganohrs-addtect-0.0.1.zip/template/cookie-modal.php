<div id="gnr-cookie-modal" class="gnr-cookie-modal">
	<div id="gnr-cookie-content">
		<p>
			当サイトはサイト利便性向上(コメントした際に入力された情報の記憶/各種認証情報の記憶/Cookie許諾情報の記憶,etc)のため「1st Person Cookie」を利用しています。
			<a id="gnr-cookie-a" href="https://ganohr4.wixsite.com/info/post/cookie%E6%9C%89%E5%8A%B9%E5%8C%96%E3%81%AE%E3%81%8A%E9%A1%98%E3%81%84">情報を確認</a>
			<button id="gnr-cookie-accept-button">了解</button>
		</p>
	</div>
</div>
