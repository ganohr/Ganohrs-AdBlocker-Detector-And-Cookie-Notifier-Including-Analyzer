<div id="gnr-modal" class="gnr-modal" style="display:none;">
	<div id="gnr-modal-content">
		<div class="gnr-modal-inner">
			<div class="gnr-modal-header">
				<h2>広告ブロッカーを利用されている方々へ</h2>
				<span id="gnr-modal-close">×</span>
			</div>
			<div class="gnr-modal-body">
				<p>当サイトは高速・高品質な記事を提供するため<span class="blue">有料レンタルサーバーで運営</span>しています。</p>
				<p>&nbsp;</p>
				<p>これはクオリティ維持に必要であり、そのため広告収入にて運営費を捻出しています。</p>
				<p>&nbsp;</p>
				<p>そこで、<span class="red">みだりに広告をブロックしている利用者</span>に対し、注意を促すこととしました。
				引き続き閲覧される方は<span class="blue">ホワイトリストに「ganohr.net」を追加</span>願います。</p>
				<p>&nbsp;</p>
				<p><a id="gnr-modal-a" href="https://ganohr.net/blog/messages-for-all-of-ad-blocker-user/">ホワイトリストへの登録方法&詳細</a></p>
				<p><label for="gnr-cookie-adb"><input type="checkbox" id="gnr-cookie-adb" name="gnr-cookie-adb">了解したので7日間は警告を非表示にして下さい</input></label></p>
			</div>
		</div>
	</div>
</div>
